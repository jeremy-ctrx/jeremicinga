# About the Monitoring Module <a id="monitoring-module-about"></a>

Please read the following chapters for more insights on this module:

* [Installation](02-Installation.md#monitoring-module-installation)
* [Configuration](03-Configuration.md#monitoring-module-configuration)
* [Security](06-Security.md#monitoring-module-security)
* [Restrict Custom Variables](10-Restrict-Custom-Variables.md#monitoring-module-restrict-access-custom-variables)
* [Hooks](20-Hooks.md#monitoring-module-hooks)
* [Add Columns to List Views](11-Add-Columns-List-Views.md#monitoring-module-add-columns-list-views)
